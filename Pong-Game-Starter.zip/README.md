# Pong Game

1. Upload all files to your GitHub repository.
2. Enable GitHub Pages (Settings > Pages > Deploy from main/root).
3. Replace placeholders:
   - YOUR_USERNAME
   - AdSense publisher ID in ads.txt
